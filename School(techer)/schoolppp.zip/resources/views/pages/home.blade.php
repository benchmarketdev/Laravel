
@extends('common.page_wrapper.index')

@section('content')
<h1></h1>

@endsection