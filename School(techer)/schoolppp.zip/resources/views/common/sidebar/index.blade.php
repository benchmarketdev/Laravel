<div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark ">
					<!-- BEGIN: Aside Menu -->
    <div 
        id="m_ver_menu" 
        class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark " 
        data-menu-vertical="true"
            data-menu-scrollable="false" data-menu-dropdown-timeout="500"  
        >
        @include('common.sidebar.nav_list')
    </div>
    <!-- END: Aside Menu -->
</div>